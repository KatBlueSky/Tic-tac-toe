// Zugriff auf HTML Elemente

// der Zähler zählt die Spielzüge
var counter = 0;
// Alle Zelle aus Spielfeld
var cells = document.querySelectorAll('#field td');
// Statuszeile für Informationen
var statusText = document.querySelector('#status');


// Start aufrufen, Spiel vorbereiten
startGame();


// Funktion um Spiel neustarten 
function startGame() {

	// das Spiel begient neu
	counter = 0;
	statusText.innerHTML = 'Wer gewinnt?';

	// eine Schleife wir gehen durch jedes Spielzelle auf dem Spielfeld 
	for (var cell of cells) {
		// machen Zell leer 
		cell.innerHTML = '';
		// wie machen ein Eventtriger (Ereignislauscher)
		// ruft beim Ereignis 'Click' function 'doTurn' auf
		cell.addEventListener('click', doTurn);
	}
}


// funktion 'doTurn' macht Spielzug bei Click auf die Zell
// 'event' ist der Click auf ein Zell
function doTurn(event) {
	// modulo 2 => counter ist gerade Zahl Wert 0 2 4 6 8
	if (counter % 2 == 0) {
		// Event.target ist gecklikte Zell => Inhalt ändert auf ein Bild X
		event.target.innerHTML = '<img src="close.png" width=100>';
	}
	// sonst => counter ist ungerade Zahl Wert 1 3 5 7
	else {
		// Event.target ist gecklikte Zelle => Inhalt ändert auf ein Bild O
		event.target.innerHTML = '<img src="circle.png" width=100>';
	}

	// wir prüfen wer hat gewonnen
	//die Bedingung prüft, ob ein Spieler das Spiel gewonnen hat, indem sie die Funktion isVictory() aufruft.
	if (isVictory()) {
		for (var cell of cells) {
			// wir machen removeEventListener damit Zellen nicht mehr gecklikt werden kann
			cell.removeEventListener('click', doTurn);
		}
		// Gewinner anzeigen
		if (counter % 2 == 0) {
			statusText.innerText = 'X ist der Gewinner!';
		}
		else {
			statusText.innerText = 'O ist der Gewinner!';
		}
	}
	// falls alle 8 Zelle sind voll aber gibst kein Gewinner dann ensteht Unentschieden
	else if (counter == 8) {
		statusText.innerText = 'Unentschieden!!!';
	}

	counter++; // nächster Spieler

	// bei dem wiederholte Click der Zell soll KEINE function 'doTurn' anrufen sein!!!
	event.target.removeEventListener('click', doTurn);
}


// mit true oder false 
// Prüft ob Gewinner. Wenn Bedingung für Gewinn erfüllt dann antwortet 'true' sonst 'false'
function isVictory() {
	// hier schreiben wir Kombinationen von Gewinn
	var combos = [
		[0, 1, 2], //hor
		[3, 4, 5], //hor
		[6, 7, 8], //hor
		[0, 3, 6], //ver
		[1, 4, 7], //ver
		[2, 5, 8], //ver
		[0, 4, 8], //dia
		[2, 4, 6], //dia
	]
	// wir schreiben eine Schleife mit allen Kombinationen
	for (var combo of combos) {
		// combo ist Array mit Nummern von 3 Zelle
		// überprüfen, ob die Symbole dadrin sind gleich und nicht alle leer
		if (cells[combo[0]].innerHTML == cells[combo[1]].innerHTML && cells[combo[1]].innerHTML == cells[combo[2]].innerHTML && cells[combo[0]].innerHTML !== '') {
			return true;
		}
	}
	return false; // noch kein Gewinn
}



